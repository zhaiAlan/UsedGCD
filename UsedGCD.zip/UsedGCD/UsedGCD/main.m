//
//  main.m
//  UsedGCD
//
//  Created by jinxin on 16/8/1.
//  Copyright © 2016年 zhaixingzhi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
