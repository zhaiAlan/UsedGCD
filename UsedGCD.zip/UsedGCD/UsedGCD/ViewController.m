//
//  ViewController.m
//  UsedGCD
//
//  Created by jinxin on 16/8/1.
//  Copyright © 2016年 zhaixingzhi. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    
    [self mainSync];;
}
/**
 *  主队列 + 异步任务 : 没有开启新线程，任务还是逐个完成的
 */
-(void)mainAsync
{
    dispatch_queue_t queue = dispatch_get_main_queue();
    dispatch_async(queue, ^{
        for (int
             i = 0; i< 6; i++) {
            NSLog(@"1----%@",[NSThread currentThread]);
        }
    });
    dispatch_async(queue, ^{
        for (int i = 0; i< 6; i++) {
            NSLog(@"2----%@",[NSThread currentThread]);
        }
    });
    dispatch_async(queue, ^{
        for (int i = 0; i< 6; i++) {
            NSLog(@"3----%@",[NSThread currentThread]);
        }
    });
    

}
/**
 *  主队列 + 同步任务：会造成死锁的进程 【切记】：不能字啊主队列中添加同步任务
 */
-(void)mainSync
{
    NSLog(@"---1");
    dispatch_queue_t queue = dispatch_get_main_queue();
    dispatch_sync(queue, ^{
        NSLog(@"不会打印");
        
//        for (int i = 0; i < 5; i++) {
//            NSLog(@"-1--%@",[NSThread currentThread]);
//        }
    });
    NSLog(@"---2");
    
//    dispatch_sync(queue, ^{
//        for (int i = 0; i < 5; i++) {
//            NSLog(@"-2--%@",[NSThread currentThread]);
//        }
//    });
//    dispatch_sync(queue, ^{
//        for (int i = 0; i < 5; i++) {
//            NSLog(@"-3--%@",[NSThread currentThread]);
//        }
//    });

    
}

/**
 *  串行队列 +异步任务,开启了新的线程，任务是逐个完成的
 
 */
-(void)serialAsync
{
    dispatch_queue_t queue = dispatch_queue_create("queue", NULL);
    
    dispatch_async(queue, ^{
        for (int
             i = 0; i< 6; i++) {
            NSLog(@"1----%@",[NSThread currentThread]);
        }
    });
    dispatch_async(queue, ^{
        for (int i = 0; i< 6; i++) {
            NSLog(@"2----%@",[NSThread currentThread]);
        }
    });
    dispatch_async(queue, ^{
        for (int i = 0; i< 6; i++) {
            NSLog(@"3----%@",[NSThread currentThread]);
        }
    });

}
/**
 *  串行队列 + 同步任务:没有开启新的线程，任务是逐个完成
 */
-(void)serialSync
{
//创建串行队列
    dispatch_queue_t queue = dispatch_queue_create("queue", DISPATCH_QUEUE_SERIAL);//这里可以用DISPATCH_QUEUE_SERIAL或者NULL都是串行队列
    dispatch_sync(queue, ^{
        for (int i = 0; i < 5; i++) {
            NSLog(@"-1--%@",[NSThread currentThread]);
        }
    });
    dispatch_sync(queue, ^{
        for (int i = 0; i < 5; i++) {
            NSLog(@"-2--%@",[NSThread currentThread]);
        }
    });
    dispatch_sync(queue, ^{
        for (int i = 0; i < 5; i++) {
            NSLog(@"-3--%@",[NSThread currentThread]);
        }
    });

}
/**
 *  全局队列 + 异步任务 ： 开启新的线程，任务是并发的
 */
-(void)globalAsync
{
    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    
    dispatch_async(queue, ^{
        for (int i = 0; i < 5; i++) {
            NSLog(@"-1--%@",[NSThread currentThread]);
        }
   
    });

    dispatch_async(queue, ^{
        for (int i = 0; i < 5; i++) {
            NSLog(@"-2--%@",[NSThread currentThread]);
        }
        
    });
    dispatch_async(queue, ^{
        for (int i = 0; i < 5; i++) {
            NSLog(@"-3--%@",[NSThread currentThread]);
        }
        
    });
}
/**
 *  全局队列 + 同步任务 ： 没有开启新线程 ，任务是逐个完成的
 */
-(void)globalSync
{
    //获得全局队列
    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    
    dispatch_sync(queue, ^{
        for (int i = 0; i < 5; i++) {
            NSLog(@"-1--%@",[NSThread currentThread]);
        }
    });
    dispatch_sync(queue, ^{
        for (int i = 0; i < 5; i++) {
            NSLog(@"-2--%@",[NSThread currentThread]);
        }
    });
    dispatch_sync(queue, ^{
        for (int i = 0; i < 5; i++) {
            NSLog(@"-3--%@",[NSThread currentThread]);
        }
    });

}

/**
 *  并发队列 + 异步任务 : 开启了新线程，任务是并发的
 *
 */
-(void)concurrentAsunc
{
    //创建并发队列
    dispatch_queue_t queue = dispatch_queue_create("myQueue", DISPATCH_QUEUE_CONCURRENT);
    //异步任务
    dispatch_async(queue, ^{
        for (int i = 0; i < 5; i++) {
            NSLog(@"-1--%@",[NSThread currentThread]);
        }
  
    });
    //异步任务
    dispatch_async(queue, ^{
        for (int i = 0; i < 5; i++) {
            NSLog(@"-2--%@",[NSThread currentThread]);
        }
        
    });
    //异步任务
    dispatch_async(queue, ^{
        for (int i = 0; i < 5; i++) {
            NSLog(@"-3--%@",[NSThread currentThread]);
        }
        
    });

}

/**
 *  并发队列 + 同步任务 ： 没有开启新的线程，任务逐个进行
 */
-(void)concurrentSync
{
    //创建并行队列
    dispatch_queue_t queue = dispatch_queue_create("myQueue", DISPATCH_QUEUE_CONCURRENT);
    //在对垒中创建任务
    //同步任务
    
    dispatch_sync(queue, ^{
        for (int i = 0; i < 5; i++) {
            NSLog(@"-1--%@",[NSThread currentThread]);
        }
    });
    dispatch_sync(queue, ^{
        for (int i = 0; i < 5; i++) {
            NSLog(@"-2--%@",[NSThread currentThread]);
        }
    });
    dispatch_sync(queue, ^{
        for (int i = 0; i < 5; i++) {
            NSLog(@"-3--%@",[NSThread currentThread]);
        }
    });

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
